
cc.FileUtils:getInstance():setPopupNotify(false)

require "config"
require "cocos.init"

local TestScene = require "TestScene"
local function main()
    -- require("app.MyApp"):create():run()
    local testScene = TestScene:create()
    cc.Director:getInstance():runWithScene(testScene)
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
