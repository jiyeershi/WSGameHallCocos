
local TestScene = class("TestScene", cc.Scene)
local luaoc = require "cocos.cocos2d.luaoc"
local json = require "cocos.cocos2d.json"

function TestScene:ctor( ... )
	-- self.super:ctor()
	local T_USERINFO = 10
	local T_CHARGE = 11
	local T_ACHIVEMENT = 12
	local T_END = 13

	local lab1 = nil

	-- local OC2LuaCallBack = function (eventType, result, msg, jsonData)
	local OC2LuaCallBack = function (jsonData)
		print(jsonData)
		lab1:setString(jsonData)
	end

	 local function onMenuPostClicked()
        local xhr = cc.XMLHttpRequest:new()
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
        xhr:open("POST", "http://game.test.api.wesai.com/intra/virtualMedal")
        -- xhr:open("POST", "http://game-pre.api.wesai.com/intra/virtualMedal")
        -- xhr:open("POST", "http://game.api.wesai.com/intra/virtualMedal")
        local function onReadyStateChanged()
            if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
                if not tolua.isnull(labelStatusCode) then
                    labelStatusCode:setString("Http Status Code:" .. xhr.statusText)
                else
                    print("ERROR: labelStatusCode is invalid!")
                end
                print(xhr.response)
                lab1:setString(xhr.response)
            else
                print("xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
            end
            xhr:unregisterScriptHandler()
        end
		xhr:registerScriptHandler(onReadyStateChanged)
        local result, uId = luaoc.callStaticMethod("WSGameCenterInterface", "getWesaiUid")
        local result1, gameId = luaoc.callStaticMethod("WSGameCenterInterface", "getGameId")
        local sendData = string.format("user_id=%s&game_id=%s&medal_value=1", uId, gameId)
        print("sendData ", sendData)
        xhr:send(sendData)
        print("waiting...")
    end

	local onClickAchivement = function ( ... )
		print("==============onClickAchivement==============")
		-- local arg = {callBack = OC2LuaCallBack,iconUrl = "http://images2015.cnblogs.com/blog/784420/201602/784420-20160217161627003-1456997293.png"}  
		-- local result, version = luaoc.callStaticMethod("WSGameCenterInterface", "doShareImage", arg)
		onMenuPostClicked()
	end

	local onClickCharge = function ( ... )
		print("==============onClickCharge==============")
		local arg = {callBack = OC2LuaCallBack}  
		local result, version = luaoc.callStaticMethod("WSGameCenterInterface", "doPay", arg)
	end

	local onClickUserInfo = function ( ... )
		print("==============onClickUserInfo==============")
		local arg = {callBack = OC2LuaCallBack}  
		local result, value = luaoc.callStaticMethod("WSGameCenterInterface", "doQueryUserInfo", arg)
		print(result, value)
		lab1:setString(value)
	end

	local onClickEnd = function ( ... )
		print("==============onClickEnd==============")
		local result, value = luaoc.callStaticMethod("WSGameCenterInterface", "stopGame")
		print(result, value)
		
	end

	local onlick = function ( pSender, event )
		local tag = pSender:getTag()
		print("event = ", event)
		if event == 0 then 
			pSender:setScale(0.8)
		else
			pSender:setScale(1.0)
		print("touch tag = ", tag)
		if tag == T_USERINFO then
			onClickUserInfo()
		elseif tag == T_CHARGE then
			onClickCharge()
		elseif tag == T_ACHIVEMENT then
			onClickAchivement()
		elseif tag == T_END then
			onClickEnd()
		end
	end
end
     


-- local labUserInfo = ccui.Text:create("UserInfo", "fonts/arial.ttf", 60)
    local labUserInfo = ccui.Button:create("userinfo.png", "userinfo.png")
	-- local labUserInfo = ccui.Text:create("UserInfo", "fonts/arial.ttf", 60)
	self:addChild(labUserInfo)
	labUserInfo:setPosition(cc.p(50, 80))
	labUserInfo:setTouchEnabled(true)
	labUserInfo:setTag(T_USERINFO)
	labUserInfo:addTouchEventListener(onlick)
	labUserInfo:setAnchorPoint(cc.p(0, 0))

	-- local labCharge = ccui.Text:create("Charge", "fonts/arial.ttf", 60)
	local labCharge = ccui.Button:create("pay.png", "pay.png")
	self:addChild(labCharge)
	labCharge:setPosition(cc.p(50, 200))
	labCharge:setTouchEnabled(true)
	labCharge:setTag(T_CHARGE)
	labCharge:addTouchEventListener(onlick)
	labCharge:setAnchorPoint(cc.p(0, 0))

	-- local labAddAchivementReq = ccui.Text:create("AddAchivementReq", "fonts/arial.ttf", 60)
	local labAddAchivementReq = ccui.Button:create("addcj.png", "addcj.png")
	self:addChild(labAddAchivementReq)
	labAddAchivementReq:setPosition(cc.p(50, 330))
	labAddAchivementReq:setTouchEnabled(true)
	labAddAchivementReq:setTag(T_ACHIVEMENT)
	labAddAchivementReq:addTouchEventListener(onlick)
	labAddAchivementReq:setAnchorPoint(cc.p(0, 0))

	-- local labEnd = ccui.Text:create("end", "fonts/arial.ttf", 60)
	local labEnd = ccui.Button:create("end.png", "end.png")
	local size = cc.Director:getInstance():getWinSize();
  
     print('---2222--size',size.height);
	self:addChild(labEnd)
	labEnd:setPosition(cc.p(50, 460))
	labEnd:setTouchEnabled(true)
	labEnd:setTag(T_END)
	labEnd:addTouchEventListener(onlick)
	labEnd:setAnchorPoint(cc.p(0, 0))

	lab1 = cc.LabelTTF:create(value, "fonts/arial.ttf", 30, cc.size(0,0), 0);
	lab1:setPosition(cc.p(350, size.height / 2))
	lab1:setAnchorPoint(cc.p(0,0.5))

	lab2 = cc.LabelTTF:create("lua游戏", "fonts/arial.ttf", 30, cc.size(0,0), 0);
	lab2:setPosition(cc.p(280, size.height - 100))
	lab2:setAnchorPoint(cc.p(0,0.5))
	self:addChild(lab2)

    self:addChild(lab1)

end

return TestScene